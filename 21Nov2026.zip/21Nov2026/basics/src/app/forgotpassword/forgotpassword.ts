import { Component } from '@angular/core';

@Component({
  imports: [],
  selector: 'app-forgotpassword',
  styleUrl: './forgotpassword.css',
  templateUrl: './forgotpassword.html',
})
export class Forgotpassword {}
