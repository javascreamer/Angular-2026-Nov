import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  imports: [FormsModule],
  selector: 'app-register',
  styleUrl: './register.css',
  templateUrl: './register.html',
})
export class Register {

    username:string = "";
    password:string = "";
    email:string = "";

    registerUser(){
       console.log("registerUser called");
       console.log("username:", this.username);
       console.log("password:", this.password);
       console.log("email:", this.email);

    }

}
