import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Login } from './login/login';
import { Register } from './register/register';
import { Forgotpassword } from './forgotpassword/forgotpassword';
import { Navbar } from './navbar/navbar';

@Component({
  imports: [RouterOutlet,Login,Register,Forgotpassword,Navbar],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  protected readonly title = signal('basics');
}
