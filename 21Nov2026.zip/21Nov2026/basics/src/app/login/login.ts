import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';

@Component({
  imports: [FormsModule],
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
export class Login {

   username:string = "";
   password:string = "";
   message: string = "";

   loginUser():void{
    console.log("username:", this.username);
    console.log("password:", this.password);

    if(this.username == "kiran" && this.password == "naveen"){
       this.message = "Logged in successfully!"
    }
    else{
       this.message ="Login failure, please check your username and password"
    }
   }


}
