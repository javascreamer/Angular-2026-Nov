class UPI{
      upi_name:string;
      constructor(upi_name:string){
                 this.upi_name = upi_name;
      }
}
class Cod{
       address:string = "";
       constructor(address:string){
                 this.address = address;
      }
}
class Netbanking{
       accountNumber:number;
        cvv:number;
constructor(accountNumber:number,cvv:number){
                 this.accountNumber = accountNumber;
                 this.cvv = cvv;
      }
}


class Payment{

     pay(upi:UPI):void;
     pay(cod:Cod):void;
     pay(netbanking:Netbanking):void;

     pay(paymenttype:UPI | Cod | Netbanking){

       if(paymenttype instanceof UPI){
          console.log(paymenttype.upi_name);
       }

       if(paymenttype instanceof Cod){
         console.log(paymenttype.address)
       }
       if(paymenttype instanceof Netbanking){
         console.log(paymenttype.accountNumber + "\t" + paymenttype.cvv)
       }
     }
}

 let cod = new Cod("Hyderabad");
 let netbanking = new Netbanking(7674747477444,111);
 let upi = new UPI("GPAY");

 let payment = new Payment();
 payment.pay(cod)


