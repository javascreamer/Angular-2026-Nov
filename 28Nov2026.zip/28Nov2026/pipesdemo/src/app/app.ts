import { CurrencyPipe, DatePipe, UpperCasePipe } from '@angular/common';
import { Component, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Customer } from './customer/customer';

@Component({
  imports: [RouterOutlet,UpperCasePipe,CurrencyPipe,DatePipe,Customer],
  selector: 'app-root',
  styleUrl: './app.css',
  templateUrl: './app.html',
})
export class App {
  
   product = {
         "name": "Number Super Buds Pro",
         "price":9999,
         "highlights":["Fast Charging Support", "Noise Cancellation"],
         "manufacturedDate": new Date()
   }

}
