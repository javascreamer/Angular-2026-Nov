import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'age',
})
export class AgePipe implements PipeTransform {
  transform(value: Date, ...args: unknown[]): unknown {

    console.log("value", value);
       const birthDate = new Date(value);
       const today = new Date();
       let age = today.getFullYear() - birthDate.getFullYear();
         const monthDifference = today.getMonth() - birthDate.getMonth();
         if(monthDifference < 0 || monthDifference === 0 && today.getDate() < birthDate.getDate())
         {
           age--;
         }
    return age + " years old";
  }
}
