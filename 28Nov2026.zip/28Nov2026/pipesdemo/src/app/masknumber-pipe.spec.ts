import { MasknumberPipe } from './masknumber-pipe';

describe('MasknumberPipe', () => {
  it('create an instance', () => {
    const pipe = new MasknumberPipe();
    expect(pipe).toBeTruthy();
  });
});
