import { TitleCasePipe } from '@angular/common';
import { Component } from '@angular/core';
import { MasknumberPipe } from '../masknumber-pipe';
import { AgePipe } from '../age-pipe';

@Component({
  imports: [TitleCasePipe,MasknumberPipe,AgePipe],
  selector: 'app-customer',
  styleUrl: './customer.css',
  templateUrl: './customer.html',
})
export class Customer {

  details = {
     "name": "KIRAN KUMAR", 
    "accountNumber": "9010888867675555",
    "accountBalance": 90000,
    "dob": new Date('2000-11-15')
  }
}
