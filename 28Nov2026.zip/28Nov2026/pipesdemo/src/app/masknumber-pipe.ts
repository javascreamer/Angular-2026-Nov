import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'masknumber',
})
export class MasknumberPipe implements PipeTransform {


    createMaskBasedOnLength(length:number,limit:any){
         let str = "";
         var newLength = length - limit;
       
           for(var i=0;i<newLength; i++){
              str = str + "*"
           }
           return str;
    }

     showLastDigits(value:string,limit:any){
        var sliceddata = value.slice(value.length -limit , value.length);
        console.log("sliceddata", sliceddata);
        let maskedData = this.createMaskBasedOnLength(value.length, limit);
        let finaldata = maskedData + sliceddata;
        return finaldata;
     }

  transform(value: any, ...args: any[]) {
         console.log("value:", value);
         console.log("args", args);
         let limit = args[0];
          let result = this.showLastDigits(value,limit)
        return result;
           
      
  }
}
