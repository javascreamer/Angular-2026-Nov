class Bank{
     bank_name: string;
     bank_code:string;
     constructor(bank_name:string, bank_code:string){
         this.bank_name = bank_name;
         this.bank_code = bank_code;
     }
}

class Customer extends Bank{
    customer_name: string;
    customer_id: string;
    customer_email: string;
    customer_balance: number;
    constructor(customer_name:string, customer_id:string, customer_email:string, customer_balance:number, bank_name:string, bank_code:string){
        super(bank_name, bank_code);
        this.customer_name = customer_name;
        this.customer_id = customer_id;
        this.customer_email = customer_email;
        this.customer_balance = customer_balance;
    }

    balanceEnquiry(): void{
      console.log(`----------------------------------------------`);
        console.log(`Customer Name: ${this.customer_name}`);
        console.log(`Customer Balance: ${this.customer_balance}`);
        console.log(`----------------------------------------------`);
       
    }

    fundTransfer(amount:number, recipient:Customer): void{
        if(this.customer_balance >= amount){
            this.customer_balance -= amount;
            recipient.customer_balance += amount;
            console.log(`Fund transfer of ${amount} successful.`);
        } else {
            console.log("Insufficient balance.");
        }
    }
  }

  let customer1 = new Customer("John Doe", "C001", "John@gmail.com", 5000, "Bank of America", "BOA001");
  console.log(customer1)
  console.log("Balance Enquiry for Customer 1:");
  customer1.balanceEnquiry();

  let customer2= new Customer("Jane Smith", "C002", "Jane@gmail.com", 3000, "Bank of America", "BOA001");
  customer2.balanceEnquiry(); 

  customer1.fundTransfer(1000, customer2);
  customer1.balanceEnquiry();
  customer2.balanceEnquiry();

