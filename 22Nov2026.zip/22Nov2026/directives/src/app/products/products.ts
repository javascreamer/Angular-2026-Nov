import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  imports: [CommonModule],
  selector: 'app-products',
  styleUrl: './products.css',
  templateUrl: './products.html',
})
export class Products {

  products:any = [];

  showProducts(){
    this.products = [
    {
      id:101,
      name:"product 1",
      price:200
    },
     {
      id:102,
      name:"product 2",
      price:400
    },
     {
      id:103,
      name:"product 3",
      price:900
    }
  ]
  }
}
