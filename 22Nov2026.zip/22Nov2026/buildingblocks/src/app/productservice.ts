import { HttpClient } from '@angular/common/http';
import { inject, Service } from '@angular/core';

@Service()
export class Productservice {

    private http =  inject(HttpClient);

     getAllProducts(){
        return this.http.get("https://fakestoreapi.com/products");
     }

}
