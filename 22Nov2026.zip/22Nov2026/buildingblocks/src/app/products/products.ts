import { Component, inject, OnInit } from '@angular/core';
import { Productservice } from '../productservice';
import { JsonPipe } from '@angular/common';

@Component({
  imports: [JsonPipe],
  selector: 'app-products',
  styleUrl: './products.css',
  templateUrl: './products.html',
})
export class Products implements OnInit {

    private productService= inject(Productservice);

      productData:any= [];


    ngOnInit(){
        console.log("ngoninit called");
        this.getAllProductsFromBackend();
        
    }

     getAllProductsFromBackend():void{

       this.productService.getAllProducts().subscribe(
        {
          next: (response) =>{
                 this.productData = response;
                  
          }
        }
       )
     }
     
}
