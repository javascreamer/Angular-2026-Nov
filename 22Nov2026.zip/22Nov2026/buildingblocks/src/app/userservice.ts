import { HttpClient } from '@angular/common/http';
import { inject, Service } from '@angular/core';



@Service()
export class Userservice {

     private http = inject(HttpClient);

      makeRegisterAPI(userDetails:any){
           this.http.post("https://fakestoreapi.com/users", userDetails).subscribe(
            {
                next: function(response){
                    console.log(response);
                     if("id" in response){
                        alert("registration successful")
                     }
                     else{
                        alert("registration failure")
                     }
                }
            }
           )
      }

      makeLoginAPI(loginDetails:any){
          console.log("login details", loginDetails);

          this.http.post("https://fakestoreapi.com/auth/login",loginDetails).subscribe(
            {
                next: function(response){
                      console.log("api call response:",response);
                },
                complete: function(){
                     console.log("request processing completed");
                },
                error: function(errorDetails){
                    console.log("error occured", errorDetails);
                }
            }
          )
      }

}
