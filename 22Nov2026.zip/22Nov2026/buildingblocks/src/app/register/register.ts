import { Component, inject } from '@angular/core';
import { Userservice } from '../userservice';
import { FormsModule } from '@angular/forms';

@Component({
  imports: [FormsModule],
  selector: 'app-register',
  styleUrl: './register.css',
  templateUrl: './register.html',
})
export class Register {

    username:string = "";
    password:string = "";
    email: string = "";

    private userService = inject(Userservice);

    registerUser(){

       let userInfo = {
            username: this.username,
            password: this.password,
            email: this.email
       }

         this.userService.makeRegisterAPI(userInfo);

    }

}
