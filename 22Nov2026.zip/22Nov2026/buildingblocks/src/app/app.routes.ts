import { Routes } from '@angular/router';
import { Login } from './login/login';
import { Register } from './register/register';
import { Products } from './products/products';

export const routes: Routes = [
    {
        path:"login",
        component:Login
    },
    {
        path:"register",
        component:Register
    },
    {
        path:'products',
        component:Products
    }
];
