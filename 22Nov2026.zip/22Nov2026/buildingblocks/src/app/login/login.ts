import { Component, inject } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Userservice } from '../userservice';

@Component({
  imports: [FormsModule],
  selector: 'app-login',
  styleUrl: './login.css',
  templateUrl: './login.html',
})
export class Login {

  username:string = "";
  password:string = "";

  private userService = inject(Userservice);

   loginUser(){
    
      let userdetails = {
           username: this.username,
           password: this.password
      }

      this.userService.makeLoginAPI(userdetails);

   }


}
