interface User{
   login(username:string,password:string):void;
   forgotPassword(email:string):void;
   socialLogin():void;
   otpLogin(mobilenumber: number):void;
}

abstract class UserImpl implements User{

    login(username: string, password: string): void {
       console.log("Login success");
    }

    forgotPassword(email: string): void {
      console.log("Password reset link sent to the email");
    }

    abstract socialLogin():void;
    abstract otpLogin(mobilenumber: number): void;

}

class UserImplHelper extends UserImpl{

  socialLogin():void{
    console.log("Login with LinkedIn, Github");
  }
   otpLogin(mobilenumber: number):void{
    console.log("Login with OTP");
   }
}

let user:User = new UserImplHelper(); 

 user.forgotPassword("anc");
 user.login("sd","asdf");
 user.socialLogin();
 user.otpLogin(9010101010);
